﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace numbertowords
{
    public partial class Form1 : Form
    {
        private static String[] units = { "Zero", "One", "Two", "Three",
    "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven",
    "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
    "Seventeen", "Eighteen", "Nineteen" };
        private static String[] tens = { "", "", "Twenty", "Thirty", "Forty",
    "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };
        public Form1()
        {
            InitializeComponent();
        }
        public string indiannsystem(double getnumber)
        {
            string result = "";
            if (getnumber < 20)
            {
                return units[Convert.ToInt32(getnumber)];
            }
            else if (getnumber < 100)
            {
                return tens[Convert.ToInt32(getnumber) / 10] + ((Convert.ToInt32(getnumber) % 10 == 0) ? "" : " " + units[Convert.ToInt32(getnumber) % 10]);
            }
            result = "" + result + getwords(getnumber, 1000000000, "Arab");//9 zeros
            if (Is_stop(getnumber, 1000000000))//9 zeros
            {
                return result;
            }
            getnumber = getnumber % 1000000000;// 9 zeros
            result = "" + result + getwords(getnumber, 10000000, "crore");//7 zeros
            if (Is_stop(getnumber, 10000000))//7 zeros
            {
                return result;
            }
            getnumber = getnumber % 10000000;// 7 zeros
            result = "" + result + getwords(getnumber, 100000, "lakh");//5 zeros
            if (Is_stop(getnumber, 100000))//7 zeros
            {
                return result;
            }
            getnumber = getnumber % 100000;// 7 zeros
            result = "" + result + getwords(getnumber, 1000, "thousand");//3 zeros
            if (Is_stop(getnumber, 1000))//3 zeros
            {
                return result;
            }
            getnumber = getnumber % 1000;// 3 zeros
            result = "" + result + getwords(getnumber, 100, "hundred");//2 zeros
            if (Is_stop(getnumber, 100))//2 zeros
            {
                return result;
            }
            getnumber = getnumber % 100;// 2 zeros
            return result + " " + getnum(getnumber);
        }
        public string americansystem(double getnumber)
        {
            string result = "";
            if (getnumber < 20)
            {
                return units[Convert.ToInt32(getnumber)];
            }
            else if (getnumber < 100)
            {
                return tens[Convert.ToInt32(getnumber) / 10] + ((Convert.ToInt32(getnumber) % 10 == 0) ? "" : " " + units[Convert.ToInt32(getnumber) % 10]);
            }
            result= "" + result + getwords(getnumber, 1000000000, "billion");//9 zeros
            if(Is_stop(getnumber, 1000000000))//9 zeros
            {
                return result;
            }
            getnumber = getnumber % 1000000000;// 9 zeros
            result = "" + result + getwords(getnumber, 1000000, "million");//6 zeros
            if (Is_stop(getnumber, 1000000))//6 zeros
            {
                return result;
            }
            getnumber = getnumber % 1000000;// 6 zeros
            result = "" + result + getwords(getnumber, 1000, "thousand");//3 zeros
            if (Is_stop(getnumber, 1000))//3 zeros
            {
                return result;
            }
            getnumber = getnumber % 1000;// 3 zeros
            result = "" + result + getwords(getnumber, 100, "hundred");//2 zeros
            if (Is_stop(getnumber, 100))//2 zeros
            {
                return result;
            }
            getnumber = getnumber % 100;// 2 zeros
            return result + " " + getnum(getnumber);
        }
        public string getwords(double number,double gets,string scale)
        {
            int num = Convert.ToInt32(number / gets);
            if(num==0)
            {
                return "";
            }
            else
            {
                return " " + getnum(num) + " " + scale;
            }
        }
        public string getnum(double getnumber)
        {
            if(getnumber<20)
            {
                return units[Convert.ToInt32(getnumber)];
            }
            else if(getnumber<100)
            {
                return tens[Convert.ToInt32(getnumber) / 10] + ((Convert.ToInt32(getnumber) % 10 == 0) ? "" : " " + units[Convert.ToInt32(getnumber) % 10]);
            }
            else if(getnumber<1000)
            {
                string gets = getnumber.ToString().Remove(0, 1);
                double remain = Convert.ToDouble(gets);
                return units[Convert.ToInt32(getnumber)/100]+" hundred "+ tens[Convert.ToInt32(remain) / 10] + ((Convert.ToInt32(remain) % 10 == 0) ? "" : " " + units[Convert.ToInt32(remain) % 10]);
            }
            else
            {
                return getnumber.ToString();
            }
        }
        public bool Is_stop(double number,double gets)
        {
            if(number%gets==0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label1.Text = americansystem(Convert.ToDouble(textBox1.Text));
            label2.Text = indiannsystem(Convert.ToDouble(textBox1.Text));
        }
    }
}
